﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace StarGate
{
    public class Bullet
    {
        private Vector2 position;
        private Texture2D texture;
        private Rectangle rect;
        private Vector2 velocity;
        private SpriteEffects effect;

        public Bullet(Vector2 position, Texture2D texture, Vector2 velocity)
        {
            this.position = position;
            rect = new Rectangle((int)position.X, (int)position.Y, 45, 2);
            this.texture = texture;
            this.velocity = velocity;
            if (velocity.X > 0)
                effect = SpriteEffects.None;
            else
                effect = SpriteEffects.FlipHorizontally;
        }

        public void Update()
        {
            position += velocity;
            rect.X = (int)position.X;
            rect.Y = (int)position.Y;
        }

        public Rectangle getRect()
        {
            return rect;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, rect, null, Color.White, 0, Vector2.Zero, effect, 0);
        }
    }
}