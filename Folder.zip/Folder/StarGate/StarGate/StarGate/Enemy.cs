﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace StarGate
{
    public class Enemy
    {
        private Vector2 position;
        private Texture2D texture;
        private Rectangle drawRect;
        private Rectangle collisionRect;
        private float speed;
        private Vector2 velocity;
        private SpriteEffects effect;
        private bool spinning;
        private bool isAlive = true;
        private float rotation;
        int timer;
        private Texture2D c1;
        private Texture2D exp;
        public Enemy(Vector2 position, Vector2 size, Texture2D texture, float speed, bool spinning, Texture2D exp)
        {
            this.position = position;
            this.speed = speed;
            drawRect = new Rectangle((int)position.X, (int)position.Y, (int)size.X, (int)size.Y);
            collisionRect = new Rectangle((int)position.X, (int)position.Y, (int)size.X, (int)size.Y);
            c1 = texture;
            this.texture = texture;
            this.exp = exp;
            this.spinning = spinning;
        }


        public void Update(Player player, List<Enemy> enemies)
        {

            velocity = player.getPosition() - position;
            velocity.Normalize();
            if (velocity.X < 0)
                effect = SpriteEffects.FlipHorizontally;
            else if (velocity.X > 0)
                effect = SpriteEffects.None;
            velocity *= speed;
            if (!isAlive)
                velocity = Vector2.Zero;
            position += velocity;
            drawRect.X = (int)position.X;
            drawRect.Y = (int)position.Y;
            if (spinning && isAlive == true)
                rotation += 0.5f;
            collisionRect.X = drawRect.X;
            collisionRect.Y = drawRect.Y;
            if (spinning)
            {
                collisionRect.X -= drawRect.Width / 2;
                collisionRect.Y -= drawRect.Height / 2;
            }
            CollideWithPlayer(player);
            if (isAlive == false)
            {
                timer++;
                c1 = exp;
                velocity = Vector2.Zero;
            }
            if (timer > 60)
            {
                enemies.Remove(this);
            }
        }

        private void CollideWithPlayer(Player player)
        {
            if (collisionRect.Intersects(player.getRect()))
                player.setAlive(false);
        }

        public void setPosition(Vector2 position)
        {
            this.position = position;
        }
        public Vector2 getPosition()
        {
            return position;
        }
        public Texture2D getTex()
        {
            return texture;
        }

        public bool touchingBullet(List<Bullet> bullets)
        {
            bool touching = false;
            foreach (Bullet bullet in bullets)
            {
                if (bullet.getRect().Intersects(collisionRect))
                {
                    touching = true;
                    break;
                }
            }
            return touching;
        }
        public void Draw(SpriteBatch spriteBatch)
        {
            if (!spinning)
                spriteBatch.Draw(c1, drawRect, null, Color.White);
            else
            {
                spriteBatch.Draw(c1, drawRect, null, Color.White, rotation, new Vector2(texture.Width, texture.Height) / 2, effect, 0);
            }
        }
        public void setAlive(bool a)
        {
            isAlive = a;

        }
    }
}