using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace StarGate
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Texture2D afterShip;
        Texture2D ship;
        Texture2D background;
        Texture2D backgroundd;
        Texture2D background2;
        Rectangle back1, back2;
        KeyboardState oldKB;
        Texture2D bulletTex;
        Texture2D explosion;
        Texture2D boost;
        static Rectangle rect;
        Texture2D pinkEnemyTex, greenEnemyTex, orangeEnemyTex;
        SpriteFont font;
        Color myColor = Color.White;
        String text = "Even so, you keep pushing onwards."+ "The seemingly innate futility of existence can be \nundermined, not only be the subjective nature of truth, but so too by the love of life you\n carry alongside you. Your love of life extends beyond the pragmatic reality, creating \nvalue in everything that makes you smile. It's okay for you to exist, it's okay for you to \nlove life. Ever closer, mankind will forget you and the universe never knew you.";
        Player player;
        int screenHeight, screenWidth;
        int spawnTimer;
        bool reachedScreenEdge;
        static Random random = new Random();
        int score = 0;
        Texture2D bullet;
        int time = 180;
        int num = 0;
        int number = 200;

        List<Enemy> enemies = new List<Enemy>();
        public static List<Bullet> bullets = new List<Bullet>();

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            graphics.IsFullScreen = true;
            graphics.ApplyChanges();

            this.Window.AllowUserResizing = true;

        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            back1 = new Rectangle(0, -1, 1600, 850);
            back2 = new Rectangle(Window.ClientBounds.Width, -1, 1600, 850);
            oldKB = Keyboard.GetState();
            base.Initialize();
            rect = new Rectangle(20, 20, 100, 25);
           
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            backgroundd = this.Content.Load<Texture2D>("Backgroundd");
            background2 = this.Content.Load<Texture2D>("Background2");
            ship = this.Content.Load<Texture2D>("Ship");
            afterShip = this.Content.Load<Texture2D>("Ship2");
            bulletTex = this.Content.Load<Texture2D>("Shoot");
            pinkEnemyTex = this.Content.Load<Texture2D>("PinkEnemy");
            greenEnemyTex = this.Content.Load<Texture2D>("GreenEnemy");
            orangeEnemyTex = this.Content.Load<Texture2D>("OrangeEnemy");
            font = this.Content.Load<SpriteFont>("Font");
            explosion = this.Content.Load<Texture2D>("Explosion");
            boost = this.Content.Load<Texture2D>("Rect");
            bullet = this.Content.Load<Texture2D>("Bullet");

            background = backgroundd;
            // TODO: use this.Content to load your game content here
            player = new Player(new Vector2(480, 200), new Vector2(35, 15), ship, afterShip, bulletTex, bullet);
        }
        public static int getWidth()
        {
            return rect.Width;
        }


        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            screenHeight = Window.ClientBounds.Height;
            screenWidth = Window.ClientBounds.Width;
            KeyboardState kb = Keyboard.GetState();

            // TODO: Add your update logic here
            number--;
            if (number == 0)
            {
                if (myColor == Color.White)
                {
                    myColor = Color.Red;
                }
                else 
                {
                    myColor = Color.White;
                }
                number = 180;
            }

            
            time--;
            if (time > 5)
            {
                num += 1;
                if (num%2 == 0)
                {
                    background = background2;
                }
                if (num % 2 != 0)
                {
                    background = backgroundd;
                }

                time = 180;
            }
            if (player.getIsAlive())
            {
                player.Update(bullets);

                scrollBackground();

                oldKB = kb;
                spawnEnemies();

                for (int i = 0; i < enemies.Count; i++)
                    enemies[i].Update(player, enemies);
                for (int i = 0; i < bullets.Count; i++)
                    bullets[i].Update();

                collision();
            }
            if (!player.getIsAlive())
            {
                if (kb.IsKeyDown(Keys.R) && oldKB.IsKeyUp(Keys.R))
                {
                    player.setAlive(true);
                    bullets.Clear();
                    enemies.Clear();
                    score = 0;
                }
            }
            if (kb.IsKeyDown(Keys.X))
            {
                rect.Width -= 1;
            }
            else if (kb.IsKeyUp(Keys.X) && rect.Width <= 100)
            {
                rect.Width += 1;
            }
            if (rect.Width > 100)
            {
                rect.Width = 100;
            }
            base.Update(gameTime);


        }

        private void scrollBackground()
        {
            back1.X -= (int)player.getVelocity().X;
            if (back1.Bottom - player.getVelocity().Y > screenHeight && back1.Top - player.getVelocity().Y < 0)
                back1.Y -= (int)player.getVelocity().Y;

            reachedScreenEdge = false;

            back2.X -= (int)player.getVelocity().X;
            if (back2.Bottom - player.getVelocity().Y > screenHeight && back2.Top - player.getVelocity().Y < 0)
                back2.Y -= (int)player.getVelocity().Y;
            else
                reachedScreenEdge = true;

            if (!reachedScreenEdge)
                for (int i = 0; i < enemies.Count; i++)
                    enemies[i].setPosition(enemies[i].getPosition() - player.getVelocity());

            if (back2.X > back1.X)
            {
                if (back2.Left > screenWidth)
                    back2.X = back1.Left - back2.Width;
                if (back1.Right < 0)
                    back1.X = back2.Right;
            }
            else
            {
                if (back1.Left > screenWidth)
                    back1.X = back2.Left - back1.Width;
                if (back2.Right < 0)
                    back2.X = back1.Right;
            }
        }

        private void spawnEnemies()
        {
            spawnTimer++;
            int spawnX = random.Next(0, screenWidth);
            int spawnY = random.Next(0, screenHeight);
            if (spawnTimer % 100 == 0)
            {
                int enemyType = random.Next(0, 3);
                if (enemyType == 0)
                    enemies.Add(new Enemy(new Vector2(spawnX, spawnY), Vector2.One * 32, orangeEnemyTex, random.Next(2, 4), true, explosion));
                else if (enemyType == 1)
                    enemies.Add(new Enemy(new Vector2(spawnX, spawnY), Vector2.One * 32, greenEnemyTex, random.Next(2, 4), false, explosion));
                else
                    enemies.Add(new Enemy(new Vector2(spawnX, spawnY), Vector2.One * 32, pinkEnemyTex, random.Next(2, 4), true, explosion));
            }
        }

        private void collision()
        {
            for (int i = 0; i < enemies.Count; i++)
                if (enemies[i].touchingBullet(bullets))
                {
                    if (enemies[i].getTex() == pinkEnemyTex)
                    {
                        score += 100;
                    }
                    if (enemies[i].getTex() == orangeEnemyTex)
                    {
                        score += 50;
                    }
                    if (enemies[i].getTex() == greenEnemyTex)
                    {
                        score += 75;
                    }
                    enemies[i].setAlive(false);

                }
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();
            spriteBatch.Draw(background, back1, Color.White);
            spriteBatch.Draw(background, back2, Color.White);
            player.Draw(spriteBatch);
            for (int i = 0; i < enemies.Count; i++)
                enemies[i].Draw(spriteBatch);
            for (int i = 0; i < bullets.Count; i++)
                bullets[i].Draw(spriteBatch);
            if (!player.getIsAlive())
                spriteBatch.DrawString(font, "Game Over. Press 'R' to restart.", new Vector2(0, 300), Color.Red);

            spriteBatch.DrawString(font, score.ToString(), new Vector2(500, 0), Color.White);
            spriteBatch.DrawString(font, text, new Vector2(0, 350), myColor);
            spriteBatch.Draw(boost, rect, Color.White);
            spriteBatch.End();

            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }
    }
}