﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace StarGate
{
    public class Player
    {
        private Rectangle rect, boostedRect;
        private Texture2D shipTexture, boostedShipTex, bulletTexture;
        private Vector2 position;
        private Vector2 velocity;

        private SpriteEffects effect;
        private KeyboardState kb, oldKb;

        private bool isLeft;
        private bool boosted;
        private bool isAlive;
        Texture2D bullet;
        List<Rectangle> arr;
        int counter;
        int timer = 3000000;
        public Player(Vector2 position, Vector2 size, Texture2D shipTexture, Texture2D boostedShipTex, Texture2D bulletTexture, Texture2D bullet)
        {
            rect = new Rectangle((int)position.X, (int)position.Y, (int)size.X, (int)size.Y);
            boostedRect = new Rectangle((int)position.X, (int)position.Y, (int)size.X + 8, (int)size.Y);
            this.shipTexture = shipTexture;
            this.boostedShipTex = boostedShipTex;
            this.bulletTexture = bulletTexture;
            this.position = position;
            isAlive = true;
            this.bullet = bullet;
            /* arr = new List<Rectangle>(6);
             for(int i = 0; i <arr.Capacity; i++)
             {
                 arr.Add(new Rectangle(950, (i * 35) + 10, 75, 35));
             }*/
        }

        public void Update(List<Bullet> bullets)
        {
            kb = Keyboard.GetState();
            boosted = kb.IsKeyDown(Keys.X) && Game1.getWidth() > 0;
            velocity = Vector2.Zero;
            if (kb.IsKeyDown(Keys.Left))
            {
                isLeft = true;
                velocity.X -= 5;
            }
            if (kb.IsKeyDown(Keys.Right))
            {
                velocity.X += 5;
                isLeft = false;
            }
            if (kb.IsKeyDown(Keys.Up))
                velocity.Y -= 5;
            if (kb.IsKeyDown(Keys.Down))
                velocity.Y += 5;
            if (boosted)
                velocity.X *= 2f;

            position.Y += velocity.Y;
            rect.X = (int)position.X;
            rect.Y = (int)position.Y;
            boostedRect.Y = rect.Y;

            if (velocity.X > 0)
                effect = SpriteEffects.FlipHorizontally;
            else if (velocity.X < 0)
                effect = SpriteEffects.None;
            /*  if (counter == 10)
              {
                  arr.Remove(arr[4]);
              }
              if (counter == 20)
              {
                  arr.Remove(arr[3]);
              }
              if (counter == 30)
              {
                  arr.Remove(arr[2]);
              }
              if (counter== 40)
              {
                  arr.Remove(arr[1]);
              }
              if (counter == 50)
              {
                  arr.Remove(arr[0]);
              }
              timer--;
              if (counter > 50)
              {
                  counter = 0;
                  timer =300;
              }*/
            Shoot(bullets);
            oldKb = kb;

        }

        private void Shoot(List<Bullet> bullets)
        {
            if (kb.IsKeyDown(Keys.Space) && oldKb.IsKeyUp(Keys.Space))
            {
                counter++;
                if (isLeft)
                    bullets.Add(new Bullet(position, bulletTexture, new Vector2(-20, 0)));
                else
                    bullets.Add(new Bullet(position, bulletTexture, new Vector2(20, 0)));
            }
        }

        public bool getIsAlive() { return isAlive; }
        public void setAlive(bool alive)
        {
            isAlive = alive;
            velocity = Vector2.Zero;
        }
        public Vector2 getVelocity() { return velocity; }
        public Vector2 getPosition() { return position; }
        public Rectangle getRect() { return rect; }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (!boosted)
                spriteBatch.Draw(shipTexture, rect, null, Color.White, 0, Vector2.Zero, effect, 0);
            else
            {
                if (isLeft)
                    spriteBatch.Draw(boostedShipTex, boostedRect, null, Color.White, 0, Vector2.Zero, effect, 0);
                else
                {
                    boostedRect.X -= 8;
                    spriteBatch.Draw(boostedShipTex, boostedRect, null, Color.White, 0, Vector2.Zero, effect, 0);
                    boostedRect.X += 8;
                }
            }


            /*if (timer > 0)
            {
            spriteBatch.Draw(bullet, arr[0], Color.White);
            spriteBatch.Draw(bullet, arr[1], Color.White);
            spriteBatch.Draw(bullet, arr[2], Color.White);
            spriteBatch.Draw(bullet, arr[3], Color.White);
            spriteBatch.Draw(bullet, arr[4], Color.White);
        }*/


        }
        public void setBoost(bool b)
        {

        }
    }
}
